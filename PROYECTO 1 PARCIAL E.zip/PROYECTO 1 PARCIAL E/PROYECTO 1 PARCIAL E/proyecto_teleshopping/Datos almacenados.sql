use [Proyecto TeleShopping]
--TABLA  USUARIO
create table usuarios
( 
id_usuario  int  primary key IDENTITY(1,1),
nombre_completo varchar(50) null,
usuario varchar(50) null,
correo varchar(60) null,
contrasena varchar(50) null,
tipo_usuario varchar(50) null
);
SELECT *FROM USUARIOS
select * from usuarios where tipo_usuario = 'Cliente'

------------------------------------------------------------

--CREAR LOS DATOS ALMACENADOS DE INGRESO DE USUARIO
GO
CREATE procedure SP_RegistrarUsuarios
@nombre_completo varchar(50),
@usuario varchar(50),
@correo varchar(70), 
@contrasena varchar (50),
@tipo_usuario varchar(50)

AS
BEGIN
	insert into usuarios(nombre_completo, usuario, correo, contrasena, tipo_usuario)
	values(@nombre_completo, @usuario, @correo, @contrasena, @tipo_usuario)
END
GO
--BUSCAR DATO USUARIO
CREATE PROCEDURE SP_BuscarCorreoUsuarios
    @Correo VARCHAR(70) 
AS
BEGIN
    SELECT id_usuario, nombre_completo, usuario, correo, contrasena, tipo_usuario
    FROM usuarios
    WHERE correo = @Correo;
END;

go
--DATOS ALMACENADOS PARA MODIFICAR DATOS DEL USUARIO
CREATE procedure SP_ModificarUsuarios
@id int, 
@nombre varchar(50),
@usuario varchar(50),
@correo varchar(70),
@contrasena varchar(50),
@tipo_usuario varchar(50)
as
update usuarios set nombre_completo = @nombre, usuario = @usuario, correo = @correo, contrasena = @contrasena, tipo_usuario = @tipo_usuario where id_usuario = @id;
GO

--ELIMINAR USUARIO
CREATE PROCEDURE SP_EliminarUsuarios
    @id int  
AS
BEGIN
    DELETE FROM usuarios WHERE id_usuario = @id; 
END;




