﻿using DATOS_TSP;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MODULO_USUARIO
{
    public partial class FormListaCliente : Form
    {
        /*instanciamos la clase de conexion*/
        Dato_ts datos = new Dato_ts();
        public FormListaCliente()
        {
            InitializeComponent();
        }

        private void FormListaCliente_Load(object sender, EventArgs e)
        {
            try
            {
                /*agregamos nuestro metodo para visualizarlo en el dataGridView*/
                dataCliente.DataSource = datos.ListaDeUsuariosCliente();
            }
            /*excepciones controladas*/
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
