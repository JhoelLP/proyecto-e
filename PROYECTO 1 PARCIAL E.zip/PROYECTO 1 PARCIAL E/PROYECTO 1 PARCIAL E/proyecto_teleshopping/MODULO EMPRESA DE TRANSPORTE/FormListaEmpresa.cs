﻿using DATOS_TSP;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MODULO_EMPRESA_DE_TRANSPORTE
{
    public partial class FormListaEmpresa : Form
    {
        /*instanciamos la clase con la conexion */
        Dato_ts datos = new Dato_ts();
        public FormListaEmpresa()
        {
            InitializeComponent();
        }

        private void FormListaEmpresa_Load(object sender, EventArgs e)
        {
            try
            {
                /*agregamos nuestro metodo para visualizarlo en el dataGridView*/
                dataEmpresa.DataSource = datos.ListaDeUsuariosEmpresa();
            }
            /*excepciones controladas*/
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
