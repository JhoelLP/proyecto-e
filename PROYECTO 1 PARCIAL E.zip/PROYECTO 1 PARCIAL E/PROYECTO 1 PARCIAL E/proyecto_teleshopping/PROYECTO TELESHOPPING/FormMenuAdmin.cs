﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MODULO_USUARIO;
using MODULO_PROVEEDOR;
using MODULO_EMPRESA_DE_TRANSPORTE;

namespace PROYECTO_TELESHOPPING
{
    public partial class FormMenuAdmin : Form
    {
        public FormMenuAdmin()
        {
            InitializeComponent();
        }
        private Form activeForm = null;
        private void contenedores(Form conten)
        {
            if (activeForm != null)
                activeForm.Close();
            activeForm = conten;
            conten.TopLevel = false;
            conten.FormBorderStyle = FormBorderStyle.None;
            conten.Dock = DockStyle.Fill;
            panelContenedor.Controls.Add(conten);
            panelContenedor.Tag = conten;
            conten.BringToFront();
            conten.Show();

        }

        private void BtnCliente_Click(object sender, EventArgs e)
        {
            contenedores(new FormListaCliente());
        }

        private void BtnProveedor_Click(object sender, EventArgs e)
        {
            contenedores(new FormListaProveedor());
        }

        private void BtnEmpresa_Click(object sender, EventArgs e)
        {
            contenedores(new FormListaEmpresa());
        }

        private void label4_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormLogin login = new FormLogin();
            login.Show();
        }
    }
}
