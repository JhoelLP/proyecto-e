﻿using DATOS_TSP;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MODULO_PROVEEDOR
{
    public partial class FormListaProveedor : Form
    {
        /*Llamamos la clase que tiene la conexion de datos*/
        Dato_ts datos = new Dato_ts();
        public FormListaProveedor()
        {
            InitializeComponent();
        }

        private void FormListaProveedor_Load(object sender, EventArgs e)
        {
            try
            {
                /*agregamos nuestro metodo para visualizarlo en el dataGridView*/
                dataProveedor.DataSource = datos.ListaDeUsuariosProveedor();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
