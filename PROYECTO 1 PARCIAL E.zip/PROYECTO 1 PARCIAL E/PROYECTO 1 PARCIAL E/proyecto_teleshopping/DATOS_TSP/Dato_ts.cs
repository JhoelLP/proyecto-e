﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DATOS_TSP
{
    public class Dato_ts
    {
        /*Metodo static para poder intanciar la clase a otro proyecto*/

        private SqlConnection conexion = new SqlConnection("Data Source=Luigi\\SQLEXPRESS; Initial Catalog=Proyecto TeleShopping;Integrated Security=True");

        public SqlConnection AbrirConexion()
        {
            if (conexion.State == ConnectionState.Closed)
                conexion.Open();
            return conexion;
        }
        public SqlConnection CerrarConexion()
        {
            if (conexion.State == ConnectionState.Open)
                conexion.Close();

            return conexion;
        }
        private static Dato_ts datos_teleshopping = new Dato_ts();
        /*Constructor*/
        public Dato_ts() { }
        /*Metodo static que retorna toda la clase*/
        public static Dato_ts getObject()
        {
            return datos_teleshopping;
        }


        /*SE CREA UNA IMPORTACION DE CONEXION POR CADA METODO DE CADA CLASE*/

        /*Metodo StoredProcedure con parametros para insertar usuario*/
        public void InsertarUsuarios(string nombre, string usuario, string correo, string contrasena, string tipoUsuario)
        {
            string conet = "SP_RegistrarUsuarios";
            /*llamamos la conexion de nuestro servidor*/

            SqlCommand command = new SqlCommand(conet, conexion);
            
                /*se especifica los procediminetos almacenados para insertar usuario*/
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@nombre_completo", nombre);
                command.Parameters.AddWithValue("@usuario", usuario);
                command.Parameters.AddWithValue("@correo", correo);
                command.Parameters.AddWithValue("@contrasena", contrasena);
                command.Parameters.AddWithValue("@tipo_usuario", tipoUsuario);
                /*Abrimos la conexion de la base de datos y se ejecuta*/
                AbrirConexion();
                command.ExecuteNonQuery();
            }
        

        /*Metodo StoredProcedure con parametros para modificar usuario */
        public void ModificarUsuarios(int id, string nombre, string usuario, string correo, string contrasena, string tipoUsuario)
        {
            string conet = "SP_ModificarUsuarios";
            /*llamamos la conexion de nuestro servidor*/

            using (SqlCommand command = new SqlCommand(conet, conexion))
            {
                /*se especifica los procediminetos almacenados para modificar usuario*/
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@id", id);
                command.Parameters.AddWithValue("@nombre", nombre);
                command.Parameters.AddWithValue("@usuario", usuario);
                command.Parameters.AddWithValue("@correo", correo);
                command.Parameters.AddWithValue("@contrasena", contrasena);
                command.Parameters.AddWithValue("@tipo_usuario", tipoUsuario);
                /*Abrimos la conexion de la base de datos y se ejecuta*/
                AbrirConexion();
                command.ExecuteNonQuery();
            }
        }


        /*Metodo StoredProcedure con parametros para buscar usuario */
        public DataTable BuscarDatosPorCorreoUsuario(string correoBuscado)
        {
            DataTable datos = new DataTable();

            /*llamamos la conexion de nuestro servidor*/

            /*se especifica los procediminetos almacenados para busar al usuario por correo*/
            SqlCommand command = new SqlCommand("SP_BuscarCorreoUsuarios", conexion);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@Correo", correoBuscado);

            try
            {
                /*Abre la conexion*/
                AbrirConexion();
                /*se ejecuta SqlAdapter para llenar la tabla con los datos almacenados*/
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(datos);
                return datos;
            }
            /*se envia un excepcion si hubo algun problema al buscar los datos*/
            catch (Exception ex)
            {
                Console.WriteLine("Error al buscar los datos: " + ex.Message);
                return datos;
            }
        }


        /*Metodo StoredProcedure con parametro para eliminar usuario */
        public void EliminarUsuario(int id)
        {
            string conet = "SP_EliminarUsuarios";
            /*llamamos la conexion de nuestro servidor*/

            using (SqlCommand command = new SqlCommand(conet, conexion))
            {
                /*se especifica los procediminetos almacenados para eliminar usuario*/
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@id", id);
                /*Abrimos la conexion de la base de datos y se ejecuta*/
                AbrirConexion();
                command.ExecuteNonQuery();
            }

        }
        public DataTable ListaDeUsuariosCliente()
        {
                using (SqlCommand command = new SqlCommand("select * from usuarios where tipo_usuario = 'Cliente'", conexion))
                {
             
                AbrirConexion();
                SqlDataAdapter data = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                data.Fill(table);
                return table;
                }         
        }

        public DataTable ListaDeUsuariosProveedor()
        {
            using (SqlCommand command = new SqlCommand("select * from usuarios where tipo_usuario = 'Proveedor'", conexion))
            {

                AbrirConexion();
                SqlDataAdapter data = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                data.Fill(table);
                return table;
            }

        }

        public DataTable ListaDeUsuariosEmpresa()
        {

            using (SqlCommand command = new SqlCommand("select * from usuarios where tipo_usuario = 'Empresa de transporte'", conexion))
            {

                AbrirConexion();
                SqlDataAdapter data = new SqlDataAdapter(command);
                DataTable table = new DataTable();
                data.Fill(table);
                return table;
            }

        }

    }
}

